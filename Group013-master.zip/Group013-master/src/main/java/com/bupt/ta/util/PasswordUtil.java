package com.bupt.ta.util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;

public final class PasswordUtil {
    private static final String ALG = "SHA-256";
    private static final int SALT_LEN = 16; // 128 bits
    private static final String DELIMITER = ":";

    private static final SecureRandom RANDOM = new SecureRandom();

    private PasswordUtil() {}

    /**
     * 生成随机盐，并返回 盐:哈希 格式的字符串。
     * @param plain 明文密码
     * @return 格式：Base64(salt) + ":" + Base64(hash)
     */
    public static String hashWithSalt(String plain) {
        byte[] salt = new byte[SALT_LEN];
        RANDOM.nextBytes(salt);
        byte[] hash = sha256(concat(salt, plain.getBytes(StandardCharsets.UTF_8)));
        return Base64.getEncoder().encodeToString(salt) + DELIMITER +
                Base64.getEncoder().encodeToString(hash);
    }

    /**
     * 验证明文密码是否与存储的 盐:哈希 字符串匹配。
     * @param plain 明文密码
     * @param stored 存储的字符串，格式：盐:哈希
     * @return 是否匹配
     */
    public static boolean checkWithSalt(String plain, String stored) {
        if (stored == null || !stored.contains(DELIMITER)) {
            // 兼容旧数据（无盐哈希）
            return legacyCheck(plain, stored);
        }
        String[] parts = stored.split(DELIMITER, 2);
        if (parts.length != 2) return false;
        byte[] salt = Base64.getDecoder().decode(parts[0]);
        byte[] expectedHash = Base64.getDecoder().decode(parts[1]);
        byte[] actualHash = sha256(concat(salt, plain.getBytes(StandardCharsets.UTF_8)));
        return MessageDigest.isEqual(actualHash, expectedHash);
    }

    // 旧版无盐验证（兼容）
    private static boolean legacyCheck(String plain, String oldHash) {
        if (oldHash == null || oldHash.isEmpty()) return false;
        String hashOfPlain = legacyHash(plain);
        return hashOfPlain.equals(oldHash);
    }

    // 旧版无盐哈希（仅用于兼容）
    public static String legacyHash(String plain) {
        try {
            MessageDigest md = MessageDigest.getInstance(ALG);
            byte[] bytes = md.digest(plain.getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(bytes);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

    // 核心：SHA-256 计算
    private static byte[] sha256(byte[] input) {
        try {
            MessageDigest md = MessageDigest.getInstance(ALG);
            return md.digest(input);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

    // 工具：拼接字节数组
    private static byte[] concat(byte[] a, byte[] b) {
        byte[] result = new byte[a.length + b.length];
        System.arraycopy(a, 0, result, 0, a.length);
        System.arraycopy(b, 0, result, a.length, b.length);
        return result;
    }
}